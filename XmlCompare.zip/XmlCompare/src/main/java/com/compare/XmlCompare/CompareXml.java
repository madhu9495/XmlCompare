package com.compare.XmlCompare;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CompareXml {
    
    
    
    public List<String> readExcel()throws IOException, InvalidFormatException {
    	
    	final String SAMPLE_XLSX_FILE_PATH = "C:\\\\\\\\Users\\\\\\\\Madhu\\\\\\\\Documents\\\\\\\\suri\\\\\\\\excel.xlsx";
    	
    	// Creating a Workbook from an Excel file (.xls or .xlsx)
        Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));

     
        /*
           ==================================================================
           Iterating over all the rows and columns in a Sheet (Multiple ways)
           ==================================================================
        */

        // Getting the Sheet at index zero
        Sheet sheet = workbook.getSheetAt(0);
        
        List<String> data = new ArrayList<String>();

        // Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();

        // you can use a for-each loop to iterate over the rows and columns
       
        for (Row row: sheet) {
            for(Cell cell: row) {
                String cellValue = dataFormatter.formatCellValue(cell);
                data.add(cellValue);
            }
            System.out.println();
        }

  
        // Closing the workbook
        workbook.close();
		return data;
        
    }


    public static void main(String[] args)throws IOException, InvalidFormatException {
    	
    	CompareXml c = new CompareXml();
    	
//    	List<String> values=c.readExcel();
//    	
//    	Iterator<String> itr = values.iterator();
//        while(itr.hasNext())
//        {
//            System.out.println(itr.next());
//        }

        }
}